<template>
  <div class="app-container">
    <!-- 顶部步进条 -->
    <header class="step-header">
      <el-steps :active="active" finish-status="success" align-center>
        <el-step title="Query Table Info" />
        <el-step title="Candidate Tables" />
        <el-step title="Model Analysis" />
      </el-steps>
    </header>

    <!-- 中间内容区域 -->
    <main class="step-content">
      <Step1 v-if="active === 0" />
      <Step2 v-else-if="active === 1" />
      <Step3 v-else-if="active === 2" />
    </main>

    <!-- 底部操作按钮 -->
    <footer class="step-footer">
      <el-button :disabled="active === 0" @click="prev">Previous</el-button>
      <el-button type="primary" :disabled="active === 2" @click="next">Next</el-button>
    </footer>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import Step1 from './components/Step1.vue'
import Step2 from './components/Step2.vue'
import Step3 from './components/Step3.vue'

const active = ref(0)
const next = () => {
  if (active.value < 2) active.value++
}
const prev = () => {
  if (active.value > 0) active.value--
}
</script>

<style scoped>
.app-container {
  display: flex;
  flex-direction: column;
  height: 100vh;
}

/* 顶部 step 栏 */
.step-header {
  padding: 16px 24px;
  border-bottom: 1px solid #ddd;
  background-color: #f9f9f9;
}

/* 中间内容区域，撑满中间 */
.step-content {
  flex: 1;
  padding: 24px;
  overflow-y: auto;
  background-color: #f5f5f5;
}

/* 底部按钮栏 */
.step-footer {
  padding: 16px 24px;
  display: flex;
  justify-content: space-between;
  border-top: 1px solid #ddd;
  background-color: #fff;
}
</style>
