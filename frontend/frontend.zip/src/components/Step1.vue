<template>
    <div>
      <h3>Query Table Information</h3>
      <el-table :data="tableData" style="width: 100%">
        <el-table-column prop="id" label="Person Id" />
        <el-table-column prop="type" label="Address Type" />
        <el-table-column prop="address" label="Address" />
        <el-table-column prop="range" label="Data Collection" />
      </el-table>
    </div>
  </template>
  
  <script setup>
  const tableData = [
    { id: '1600000US1969195', type: 'place', address: 'Rudd, Iowa', range: '2008–2012' },
    { id: '0500000US19087', type: 'county', address: 'Henry County, Iowa', range: '2013–2017' },
    { id: '0500000US19161', type: 'county', address: 'Sac County, Iowa', range: '2014–2018' },
  ]
  </script>
  