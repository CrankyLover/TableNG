<template>
    <div>
      <h3>Model Analysis</h3>
  
      <el-select v-model="model" placeholder="Select Model" style="margin-bottom: 20px">
        <el-option label="Support Vector Machine" value="svm" />
        <el-option label="Random Forest" value="rf" />
      </el-select>
  
      <div class="model-section">
        <div class="model-box">
          <h4>Query Table</h4>
          <div class="placeholder">Confusion Matrix Placeholder</div>
        </div>
        <div class="model-box">
          <h4>Augmented Table</h4>
          <div class="placeholder">Confusion Matrix Placeholder</div>
        </div>
      </div>
    </div>
  </template>
  
  <script setup>
  import { ref } from 'vue'
  const model = ref('svm')
  </script>
  
  <style scoped>
  .model-section {
    display: flex;
    gap: 20px;
  }
  
  .model-box {
    flex: 1;
    text-align: center;
    background: #fff;
    padding: 10px;
    border-radius: 6px;
    box-shadow: 0 0 4px rgba(0, 0, 0, 0.1);
  }
  
  .placeholder {
    width: 100%;
    height: 240px;
    background-color: #e0e0e0;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #999;
    font-size: 16px;
    border-radius: 4px;
  }
  </style>
  