<template>
    <div>
      <h3>Candidate Tables</h3>
      <el-collapse v-model="activeNames">
        <el-collapse-item title="education_Iowa_Graduate_Degree.csv" name="1">
          <el-table :data="data1" style="width: 100%">
            <el-table-column prop="id" label="Person Id" />
            <el-table-column prop="type" label="Address Type" />
            <el-table-column prop="desc" label="Variable Description" />
          </el-table>
        </el-collapse-item>
  
        <el-collapse-item title="education_Iowa_High_School_Diploma.csv" name="2">
          <el-table :data="data2" style="width: 100%">
            <el-table-column prop="id" label="Person Id" />
            <el-table-column prop="type" label="Address Type" />
            <el-table-column prop="address" label="Address" />
          </el-table>
        </el-collapse-item>
      </el-collapse>
    </div>
  </template>
  
  <script setup>
  import { ref } from 'vue'
  
  const activeNames = ref(['1'])
  
  const data1 = [
    { id: '1600000US1969195', type: 'place', desc: '6th grade' },
    { id: '0500000US19087', type: 'county', desc: '3rd grade' },
  ]
  
  const data2 = [
    { id: '1600000US1969195', type: 'place', address: 'Rudd, Iowa' },
    { id: '0500000US19087', type: 'county', address: 'Henry County, Iowa' },
  ]
  </script>
  